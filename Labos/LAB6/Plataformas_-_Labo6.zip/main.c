#include <stdio.h>
#include <stdlib.h>
#include <float.h>
#include <math.h>

#include "./funciones.h"

int main(int argc, char** argv){
    int x = 6;
    int y = 1;
    buscarQueso(x,y);
}
